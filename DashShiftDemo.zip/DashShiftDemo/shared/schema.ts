import { pgTable, text, serial, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").unique().notNull(),
  email: text("email").unique().notNull(),
});

export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  appName: text("app_name").notNull(),
  jobType: text("job_type").notNull(),
  pay: real("pay").notNull(),
  distance: real("distance").notNull(),
  duration: integer("duration").notNull(),
  route: text("route").notNull(),
  appColor: text("app_color").notNull(),
  icon: text("icon").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const jobActions = pgTable("job_actions", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").references(() => jobs.id),
  action: text("action").notNull(), // 'accepted' | 'rejected'
  timestamp: timestamp("timestamp").defaultNow(),
});

export const userSettings = pgTable("user_settings", {
  id: serial("id").primaryKey(),
  minPay: real("min_pay").default(5),
  maxDistance: real("max_distance").default(10),
  enabledApps: text("enabled_apps").array().default(['DoorDash', 'Uber', 'Instacart']),
  notifications: boolean("notifications").default(true),
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  createdAt: true,
});

export const insertJobActionSchema = createInsertSchema(jobActions).omit({
  id: true,
  timestamp: true,
});

export const insertUserSettingsSchema = createInsertSchema(userSettings).omit({
  id: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;
export type JobAction = typeof jobActions.$inferSelect;
export type InsertJobAction = z.infer<typeof insertJobActionSchema>;
export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
