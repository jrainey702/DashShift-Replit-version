# Gig Job Swipe Application

## Overview

This is a modern React-based application for gig workers to discover and manage delivery/rideshare jobs through a swipe interface. The app allows users to swipe through job opportunities from various platforms (DoorDash, Uber, Instacart, etc.) and provides filtering, history tracking, and user settings management.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React hooks with local state and TanStack Query for server state
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: Express sessions with PostgreSQL store

### Project Structure
- **Monorepo Setup**: Single repository with client, server, and shared code
- **Client**: `/client` - React frontend application
- **Server**: `/server` - Express.js backend API
- **Shared**: `/shared` - Common types, schemas, and utilities

## Key Components

### Frontend Components
1. **SwipeInterface**: Core swipe functionality for job cards with touch/mouse support
2. **JobCard**: Displays individual job information with app branding
3. **FiltersPanel**: Side panel for filtering jobs by pay, distance, and enabled apps
4. **HistoryPanel**: Tracks accepted and rejected jobs with timestamps
5. **SettingsPanel**: User preferences and app configuration

### Backend Components
1. **Storage Interface**: Abstraction layer for data persistence with in-memory fallback
2. **Route Handler**: Express middleware for API endpoints
3. **Vite Integration**: Development server with HMR and production static file serving

### Database Schema
- **jobs**: Core job data (app, type, pay, distance, duration, route)
- **job_actions**: User interactions (accepted/rejected) with timestamps
- **user_settings**: User preferences (filters, notifications)

## Data Flow

1. **Job Discovery**: Mock job data is filtered based on user preferences
2. **Swipe Interaction**: User swipes left (reject) or right (accept) on job cards
3. **Action Recording**: Job actions are stored locally and can be persisted to database
4. **Filter Application**: Real-time filtering based on minimum pay, maximum distance, and enabled apps
5. **History Management**: Chronological tracking of all user decisions

## External Dependencies

### Frontend Dependencies
- **UI Components**: Radix UI primitives for accessible components
- **State Management**: TanStack Query for server state synchronization
- **Form Handling**: React Hook Form with Zod validation
- **Styling**: Tailwind CSS with class-variance-authority for component variants
- **Icons**: Lucide React for consistent iconography

### Backend Dependencies
- **Database**: Drizzle ORM with PostgreSQL adapter
- **Database Provider**: Neon serverless PostgreSQL
- **Session Storage**: connect-pg-simple for PostgreSQL session store
- **Development**: tsx for TypeScript execution

### Development Tools
- **Build**: Vite with React plugin and TypeScript support
- **Linting**: TypeScript compiler for type checking
- **Database Migrations**: Drizzle Kit for schema management

## Deployment Strategy

### Development
- **Dev Server**: Vite development server with Express backend
- **Hot Reload**: Full stack HMR with Vite middleware integration
- **Database**: Drizzle Kit push for schema synchronization

### Production
- **Build Process**: 
  1. Vite builds React frontend to `/dist/public`
  2. esbuild bundles Express server to `/dist/index.js`
- **Static Serving**: Express serves built frontend files
- **Database**: PostgreSQL with connection pooling via Neon

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **NODE_ENV**: Environment detection for development features
- **Session Storage**: PostgreSQL-backed sessions for production

## Changelog

```
Changelog:
- July 08, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```