import { Job } from "@shared/schema";

export const mockJobs: Omit<Job, 'id' | 'createdAt'>[] = [
  {
    appName: "DoorDash",
    jobType: "Food Delivery",
    pay: 12.50,
    distance: 2.3,
    duration: 25,
    route: "McDonald's → 1247 Oak Street",
    appColor: "bg-red-500",
    icon: "utensils"
  },
  {
    appName: "Uber",
    jobType: "Rideshare",
    pay: 18.75,
    distance: 4.1,
    duration: 35,
    route: "Downtown → Airport",
    appColor: "bg-black",
    icon: "car"
  },
  {
    appName: "Instacart",
    jobType: "Grocery Delivery",
    pay: 22.25,
    distance: 1.8,
    duration: 45,
    route: "Whole Foods → 892 Pine Ave",
    appColor: "bg-green-500",
    icon: "shopping-cart"
  },
  {
    appName: "Grubhub",
    jobType: "Food Delivery",
    pay: 9.50,
    distance: 3.2,
    duration: 20,
    route: "Chipotle → 456 Elm Street",
    appColor: "bg-blue-500",
    icon: "shopping-bag"
  },
  {
    appName: "Amazon Flex",
    jobType: "Package Delivery",
    pay: 28.00,
    distance: 6.5,
    duration: 90,
    route: "Warehouse → Multiple stops",
    appColor: "bg-purple-500",
    icon: "package"
  },
  {
    appName: "Lyft",
    jobType: "Rideshare",
    pay: 15.25,
    distance: 3.8,
    duration: 28,
    route: "Mall → Residential Area",
    appColor: "bg-pink-500",
    icon: "car"
  },
  {
    appName: "Postmates",
    jobType: "Food Delivery",
    pay: 11.00,
    distance: 2.9,
    duration: 22,
    route: "Starbucks → Office Building",
    appColor: "bg-yellow-500",
    icon: "coffee"
  },
  {
    appName: "Shipt",
    jobType: "Grocery Delivery",
    pay: 19.75,
    distance: 4.2,
    duration: 55,
    route: "Target → Suburb",
    appColor: "bg-emerald-500",
    icon: "shopping-cart"
  }
];

export const appIcons: Record<string, string> = {
  'utensils': 'Utensils',
  'car': 'Car',
  'shopping-cart': 'ShoppingCart',
  'shopping-bag': 'ShoppingBag',
  'package': 'Package',
  'coffee': 'Coffee'
};
