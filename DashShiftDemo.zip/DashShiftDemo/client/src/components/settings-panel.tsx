import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { X, Trash2, RotateCcw, Download } from "lucide-react";
import { cn } from "@/lib/utils";

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onClearHistory: () => void;
  onResetStats: () => void;
}

interface UserProfile {
  name: string;
  email: string;
  initials: string;
}

interface NotificationSettings {
  highPayAlerts: boolean;
  nearbyJobs: boolean;
  dailySummary: boolean;
}

const mockUser: UserProfile = {
  name: "John Doe",
  email: "john.doe@email.com",
  initials: "JD"
};

export function SettingsPanel({ isOpen, onClose, onClearHistory, onResetStats }: SettingsPanelProps) {
  const [notifications, setNotifications] = useState<NotificationSettings>({
    highPayAlerts: true,
    nearbyJobs: true,
    dailySummary: false
  });

  const handleNotificationChange = (key: keyof NotificationSettings, value: boolean) => {
    setNotifications(prev => ({ ...prev, [key]: value }));
  };

  const handleExportData = () => {
    // In a real app, this would export user data
    console.log('Exporting user data...');
    // Create a mock CSV data
    const csvData = `Date,App,Action,Pay,Distance
${new Date().toISOString().split('T')[0]},DoorDash,Accepted,$12.50,2.3mi
${new Date().toISOString().split('T')[0]},Uber,Rejected,$18.75,4.1mi`;
    
    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'dashshift-data.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div 
      className={cn(
        "fixed inset-0 bg-white z-50 transform transition-transform duration-300",
        isOpen ? "translate-y-0" : "translate-y-full"
      )}
    >
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="bg-white border-b-2 border-blue-300 px-4 py-3 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Settings</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>
        
        {/* Content */}
        <ScrollArea className="flex-1">
          <div className="p-4 space-y-6">
            
            {/* Profile Section */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Profile</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <Avatar className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600">
                    <AvatarFallback className="text-white font-bold text-xl">
                      {mockUser.initials}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium text-lg">{mockUser.name}</div>
                    <div className="text-gray-500 text-sm">{mockUser.email}</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Notification Preferences */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Notifications</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="high-pay" className="text-sm font-medium">
                    High-pay job alerts
                  </Label>
                  <Switch
                    id="high-pay"
                    checked={notifications.highPayAlerts}
                    onCheckedChange={(checked) => handleNotificationChange('highPayAlerts', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="nearby-jobs" className="text-sm font-medium">
                    Nearby job notifications
                  </Label>
                  <Switch
                    id="nearby-jobs"
                    checked={notifications.nearbyJobs}
                    onCheckedChange={(checked) => handleNotificationChange('nearbyJobs', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="daily-summary" className="text-sm font-medium">
                    Daily summary
                  </Label>
                  <Switch
                    id="daily-summary"
                    checked={notifications.dailySummary}
                    onCheckedChange={(checked) => handleNotificationChange('dailySummary', checked)}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Quick Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Quick Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={onClearHistory}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Clear job history
                </Button>
                
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={onResetStats}
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reset statistics
                </Button>
                
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={handleExportData}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export data
                </Button>
              </CardContent>
            </Card>

            {/* App Information */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">About</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm text-gray-600">
                  <div>DashShift v1.0.0</div>
                  <div>Gig job matching prototype</div>
                  <div className="text-xs text-gray-400 mt-4">
                    This is a demonstration prototype for testing swipe-based job matching interfaces.
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
