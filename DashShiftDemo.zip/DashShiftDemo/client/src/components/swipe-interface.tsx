import { useState, useEffect, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { JobCard } from "./job-card";
import { useSwipe } from "@/hooks/use-swipe";
import { mockJobs } from "@/data/mock-jobs";
import { Job, JobAction } from "@shared/schema";
import { X, Check, History } from "lucide-react";

interface SwipeInterfaceProps {
  onJobAction: (action: 'accepted' | 'rejected', job: Omit<Job, 'id' | 'createdAt'>) => void;
  onToggleHistory: () => void;
  filters: {
    minPay: number;
    maxDistance: number;
    enabledApps: string[];
  };
}

export function SwipeInterface({ onJobAction, onToggleHistory, filters }: SwipeInterfaceProps) {
  const [currentJobIndex, setCurrentJobIndex] = useState(0);
  const [filteredJobs, setFilteredJobs] = useState(mockJobs);
  const [isAnimating, setIsAnimating] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  // Filter jobs based on current filters
  useEffect(() => {
    const filtered = mockJobs.filter(job => 
      job.pay >= filters.minPay &&
      job.distance <= filters.maxDistance &&
      filters.enabledApps.includes(job.appName)
    );
    setFilteredJobs(filtered);
    setCurrentJobIndex(0);
  }, [filters]);

  const currentJob = filteredJobs[currentJobIndex];
  const hasMoreJobs = currentJobIndex < filteredJobs.length;

  const handleAccept = () => {
    if (!currentJob || isAnimating) return;
    setIsAnimating(true);
    onJobAction('accepted', currentJob);
    
    setTimeout(() => {
      setCurrentJobIndex(prev => prev + 1);
      setIsAnimating(false);
      swipeControls.resetSwipe();
    }, 300);
  };

  const handleReject = () => {
    if (!currentJob || isAnimating) return;
    setIsAnimating(true);
    onJobAction('rejected', currentJob);
    
    setTimeout(() => {
      setCurrentJobIndex(prev => prev + 1);
      setIsAnimating(false);
      swipeControls.resetSwipe();
    }, 300);
  };

  const swipeControls = useSwipe({
    onSwipeLeft: handleReject,
    onSwipeRight: handleAccept,
    threshold: 100
  });

  const handleMouseDown = (e: React.MouseEvent) => {
    if (isAnimating) return;
    swipeControls.startSwipe(e.clientX);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (swipeControls.swipeState.isDragging) {
      e.preventDefault();
      swipeControls.updateSwipe(e.clientX);
    }
  };

  const handleMouseUp = () => {
    if (swipeControls.swipeState.isDragging) {
      swipeControls.endSwipe();
    }
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (isAnimating) return;
    swipeControls.startSwipe(e.touches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (swipeControls.swipeState.isDragging) {
      e.preventDefault();
      swipeControls.updateSwipe(e.touches[0].clientX);
    }
  };

  const handleTouchEnd = () => {
    if (swipeControls.swipeState.isDragging) {
      swipeControls.endSwipe();
    }
  };

  const resetJobs = () => {
    setCurrentJobIndex(0);
  };

  if (!hasMoreJobs) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="text-center">
          <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
            <History className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No more jobs right now</h3>
          <p className="text-gray-500 text-sm mb-4">We'll notify you when new opportunities are available</p>
          <Button onClick={resetJobs} className="bg-blue-500 hover:bg-blue-600">
            Reload Jobs
          </Button>
        </div>
      </div>
    );
  }

  const { deltaX, rotation } = swipeControls.swipeState;
  const transform = deltaX !== 0 ? `translateX(${deltaX}px) rotate(${rotation}deg)` : undefined;
  
  const showOverlay = deltaX > 50 ? 'accept' : deltaX < -50 ? 'reject' : null;
  const overlayOpacity = showOverlay ? Math.min(0.8, Math.abs(deltaX - 50) / 100) : 0;

  return (
    <div className="flex-1 relative overflow-hidden">
      {/* Job Card Stack */}
      <div className="absolute inset-0 flex items-center justify-center p-4">
        
        {/* Background Cards */}
        <div className="absolute inset-4">
          <div className="bg-white rounded-2xl shadow-md transform scale-95 opacity-50 h-full border border-gray-100"></div>
        </div>
        <div className="absolute inset-4">
          <div className="bg-white rounded-2xl shadow-lg transform scale-97 opacity-75 h-full border border-gray-100"></div>
        </div>

        {/* Active Job Card */}
        <div 
          ref={cardRef}
          className="relative w-full max-w-sm cursor-grab active:cursor-grabbing select-none"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          style={{ 
            transform: isAnimating ? 
              (swipeControls.swipeState.deltaX > 0 ? 'translateX(100%) rotate(30deg)' : 'translateX(-100%) rotate(-30deg)') 
              : transform,
            transition: isAnimating ? 'transform 0.3s ease-out' : 'none'
          }}
        >
          <JobCard
            job={currentJob}
            showOverlay={showOverlay}
            overlayOpacity={overlayOpacity}
          />
        </div>
      </div>

      {/* Action Buttons */}
      <div className="absolute bottom-4 left-0 right-0 px-4">
        <div className="flex justify-center space-x-6">
          <Button
            size="lg"
            variant="destructive"
            className="w-14 h-14 rounded-full p-0 shadow-lg hover:scale-105 active:scale-95 transition-transform"
            onClick={handleReject}
            disabled={isAnimating}
          >
            <X className="w-6 h-6" />
          </Button>
          
          <Button
            size="lg"
            variant="outline"
            className="w-12 h-12 rounded-full p-0"
            onClick={onToggleHistory}
          >
            <History className="w-5 h-5" />
          </Button>
          
          <Button
            size="lg"
            className="w-14 h-14 rounded-full p-0 bg-emerald-500 hover:bg-emerald-600 shadow-lg hover:scale-105 active:scale-95 transition-transform"
            onClick={handleAccept}
            disabled={isAnimating}
          >
            <Check className="w-6 h-6" />
          </Button>
        </div>
      </div>
    </div>
  );
}
