import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import * as LucideIcons from "lucide-react";
import { Job, JobAction } from "@shared/schema";
import { appIcons } from "@/data/mock-jobs";
import { X, CheckCircle, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface HistoryPanelProps {
  isOpen: boolean;
  onClose: () => void;
  acceptedJobs: Array<Omit<Job, 'id' | 'createdAt'> & { timestamp: Date }>;
  rejectedJobs: Array<Omit<Job, 'id' | 'createdAt'> & { timestamp: Date }>;
}

export function HistoryPanel({ isOpen, onClose, acceptedJobs, rejectedJobs }: HistoryPanelProps) {
  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} min ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  };

  const JobHistoryItem = ({ 
    job, 
    type, 
    timestamp 
  }: { 
    job: Omit<Job, 'id' | 'createdAt'>, 
    type: 'accepted' | 'rejected',
    timestamp: Date 
  }) => {
    const IconComponent = LucideIcons[appIcons[job.icon] as keyof typeof LucideIcons] as any;
    
    return (
      <Card className={cn(
        "border",
        type === 'accepted' ? "bg-emerald-50 border-emerald-200" : "bg-red-50 border-red-200"
      )}>
        <CardContent className="p-3">
          <div className="flex justify-between items-start">
            <div className="flex items-center space-x-2">
              <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", job.appColor)}>
                {IconComponent && <IconComponent className="w-4 h-4 text-white" />}
              </div>
              <div>
                <div className="font-medium text-sm">{job.appName}</div>
                <div className="text-xs text-gray-500">{job.distance} mi • ${job.pay.toFixed(2)}</div>
              </div>
            </div>
            <div className={cn(
              "text-xs",
              type === 'accepted' ? "text-emerald-600" : "text-red-600"
            )}>
              {formatTimeAgo(timestamp)}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div 
      className={cn(
        "fixed inset-0 bg-white z-50 transform transition-transform duration-300",
        isOpen ? "translate-y-0" : "translate-y-full"
      )}
    >
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="bg-white border-b-2 border-blue-300 px-4 py-3 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Job History</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>
        
        {/* Content */}
        <ScrollArea className="flex-1">
          <div className="p-4 space-y-6">
            
            {/* Accepted Jobs */}
            <div>
              <h3 className="font-medium text-emerald-700 mb-3 flex items-center">
                <CheckCircle className="w-4 h-4 mr-2" />
                Recently Accepted ({acceptedJobs.slice(-5).length})
              </h3>
              
              {acceptedJobs.slice(-5).length > 0 ? (
                <div className="space-y-2">
                  {acceptedJobs.slice(-5).reverse().map((job, index) => (
                    <JobHistoryItem
                      key={`accepted-${index}`}
                      job={job}
                      type="accepted"
                      timestamp={job.timestamp}
                    />
                  ))}
                </div>
              ) : (
                <Card className="bg-gray-50 border-gray-200">
                  <CardContent className="p-4 text-center text-gray-500 text-sm">
                    No accepted jobs yet
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Rejected Jobs */}
            <div>
              <h3 className="font-medium text-red-700 mb-3 flex items-center">
                <XCircle className="w-4 h-4 mr-2" />
                Recently Rejected ({rejectedJobs.slice(-5).length})
              </h3>
              
              {rejectedJobs.slice(-5).length > 0 ? (
                <div className="space-y-2">
                  {rejectedJobs.slice(-5).reverse().map((job, index) => (
                    <JobHistoryItem
                      key={`rejected-${index}`}
                      job={job}
                      type="rejected"
                      timestamp={job.timestamp}
                    />
                  ))}
                </div>
              ) : (
                <Card className="bg-gray-50 border-gray-200">
                  <CardContent className="p-4 text-center text-gray-500 text-sm">
                    No rejected jobs yet
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
