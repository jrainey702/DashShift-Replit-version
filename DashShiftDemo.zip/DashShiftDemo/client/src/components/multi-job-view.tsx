import { useState, useEffect, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { JobCard } from "./job-card";
import { mockJobs } from "@/data/mock-jobs";
import { Job } from "@shared/schema";
import { X, Check, History, RefreshCw } from "lucide-react";
import { cn } from "@/lib/utils";

interface MultiJobViewProps {
  onJobAction: (action: 'accepted' | 'rejected', job: Omit<Job, 'id' | 'createdAt'>) => void;
  onToggleHistory: () => void;
  filters: {
    minPay: number;
    maxDistance: number;
    enabledApps: string[];
  };
}

export function MultiJobView({ onJobAction, onToggleHistory, filters }: MultiJobViewProps) {
  const [processedJobIds, setProcessedJobIds] = useState<Set<string>>(new Set());
  const [actioningJobs, setActioningJobs] = useState<Set<string>>(new Set());
  
  const jobsToShow = 4;

  // Generate a unique ID for each job for tracking
  const generateJobId = (job: Omit<Job, 'id' | 'createdAt'>, index: number) => {
    return `${job.appName}-${job.pay}-${job.distance}-${index}`;
  };

  // Filter jobs and get available ones
  const availableJobs = useMemo(() => {
    const filtered = mockJobs.filter(job => 
      job.pay >= filters.minPay &&
      job.distance <= filters.maxDistance &&
      filters.enabledApps.includes(job.appName)
    );
    
    return filtered
      .map((job, index) => ({ ...job, jobId: generateJobId(job, index) }))
      .filter(job => !processedJobIds.has(job.jobId));
  }, [filters, processedJobIds]);

  const currentJobs = availableJobs.slice(0, jobsToShow);

  const handleJobAction = (action: 'accepted' | 'rejected', job: Omit<Job, 'id' | 'createdAt'> & { jobId: string }) => {
    setActioningJobs(prev => new Set(prev.add(job.jobId)));
    onJobAction(action, job);
    
    // Remove the job from available jobs after animation
    setTimeout(() => {
      setProcessedJobIds(prev => new Set(prev.add(job.jobId)));
      setActioningJobs(prev => {
        const newSet = new Set(prev);
        newSet.delete(job.jobId);
        return newSet;
      });
    }, 300);
  };

  const resetJobs = () => {
    setProcessedJobIds(new Set());
    setActioningJobs(new Set());
  };

  if (availableJobs.length === 0 && processedJobIds.size === 0) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="text-center">
          <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
            <History className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No jobs match your filters</h3>
          <p className="text-gray-500 text-sm mb-4">Try adjusting your filters to see more opportunities</p>
        </div>
      </div>
    );
  }

  if (currentJobs.length === 0 && processedJobIds.size > 0) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="text-center">
          <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
            <RefreshCw className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">All available jobs reviewed</h3>
          <p className="text-gray-500 text-sm mb-4">You've seen all jobs matching your current filters</p>
          <Button onClick={resetJobs} className="bg-blue-500 hover:bg-blue-600">
            <RefreshCw className="w-4 h-4 mr-2" />
            Show Jobs Again
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Jobs Grid */}
      <div className="flex-1 p-4 overflow-y-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 max-w-7xl mx-auto">
          {currentJobs.map((job) => {
            const isActioning = actioningJobs.has(job.jobId);
            
            return (
              <div 
                key={job.jobId}
                className={cn(
                  "relative transition-all duration-300",
                  isActioning && "opacity-50 scale-95"
                )}
              >
                <JobCard
                  job={job}
                  className="h-80"
                />
                
                {/* Action Buttons Overlay */}
                <div className="absolute bottom-4 left-0 right-0 px-4">
                  <div className="flex justify-center space-x-4">
                    <Button
                      size="sm"
                      variant="destructive"
                      className="w-12 h-12 rounded-full p-0 shadow-lg hover:scale-105 active:scale-95 transition-transform"
                      onClick={() => handleJobAction('rejected', job)}
                      disabled={isActioning}
                    >
                      <X className="w-5 h-5" />
                    </Button>
                    
                    <Button
                      size="sm"
                      className="w-12 h-12 rounded-full p-0 bg-emerald-500 hover:bg-emerald-600 shadow-lg hover:scale-105 active:scale-95 transition-transform"
                      onClick={() => handleJobAction('accepted', job)}
                      disabled={isActioning}
                    >
                      <Check className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="border-t-2 border-blue-300 bg-white px-4 py-3">
        <div className="flex justify-between items-center max-w-7xl mx-auto">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-500">
              {availableJobs.length} jobs available
            </span>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={onToggleHistory}
            className="text-blue-600 border-blue-300 hover:bg-blue-50"
          >
            <History className="w-4 h-4 mr-1" />
            History
          </Button>

          <div className="flex items-center space-x-2">
            {processedJobIds.size > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={resetJobs}
                className="text-blue-600 border-blue-300 hover:bg-blue-50"
              >
                <RefreshCw className="w-4 h-4 mr-1" />
                Reset
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}