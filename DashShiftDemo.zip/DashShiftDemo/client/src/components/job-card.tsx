import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import * as LucideIcons from "lucide-react";
import { Job } from "@shared/schema";
import { appIcons } from "@/data/mock-jobs";
import { cn } from "@/lib/utils";

interface JobCardProps {
  job: Omit<Job, 'id' | 'createdAt'>;
  transform?: string;
  opacity?: number;
  showOverlay?: 'accept' | 'reject' | null;
  overlayOpacity?: number;
  className?: string;
}

export function JobCard({ 
  job, 
  transform, 
  opacity = 1, 
  showOverlay, 
  overlayOpacity = 0,
  className 
}: JobCardProps) {
  const IconComponent = LucideIcons[appIcons[job.icon] as keyof typeof LucideIcons] as any;

  return (
    <Card 
      className={cn(
        "relative w-full h-96 overflow-hidden border-2 border-blue-300 shadow-xl bg-white",
        className
      )}
      style={{ 
        transform,
        opacity,
        transition: transform ? 'none' : 'transform 0.3s ease-out'
      }}
    >
      <div className="p-6 h-full flex flex-col">
        {/* App Logo and Name */}
        <div className="flex items-center space-x-3 mb-4">
          <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center", job.appColor)}>
            {IconComponent && <IconComponent className="w-6 h-6 text-white" />}
          </div>
          <div>
            <div className="font-semibold text-lg text-gray-900">{job.appName}</div>
            <div className="text-gray-500 text-sm">{job.jobType}</div>
          </div>
        </div>

        {/* Job Details */}
        <div className="flex-1 space-y-4">
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
            <div className="text-emerald-700 text-sm font-medium mb-1">Estimated Pay</div>
            <div className="text-emerald-900 text-2xl font-bold">${job.pay.toFixed(2)}</div>
            <div className="text-emerald-600 text-xs">+ tips</div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <div className="text-blue-700 text-xs font-medium mb-1">Distance</div>
              <div className="text-blue-900 font-semibold">{job.distance} mi</div>
            </div>
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
              <div className="text-purple-700 text-xs font-medium mb-1">Duration</div>
              <div className="text-purple-900 font-semibold">{job.duration} min</div>
            </div>
          </div>

          <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
            <div className="text-gray-700 text-xs font-medium mb-2">Route</div>
            <div className="text-gray-900 text-sm">{job.route}</div>
          </div>
        </div>

        {/* Action Hints */}
        <div className="flex justify-between items-center mt-4 text-xs text-gray-400">
          <div className="flex items-center space-x-1">
            <LucideIcons.X className="w-3 h-3 text-red-400" />
            <span>Swipe left to reject</span>
          </div>
          <div className="flex items-center space-x-1">
            <span>Swipe right to accept</span>
            <LucideIcons.Check className="w-3 h-3 text-emerald-400" />
          </div>
        </div>
      </div>

      {/* Swipe Overlays */}
      {showOverlay === 'accept' && (
        <div 
          className="absolute inset-0 bg-emerald-500 bg-opacity-90 flex items-center justify-center transition-opacity duration-200"
          style={{ opacity: overlayOpacity }}
        >
          <div className="text-center text-white">
            <LucideIcons.Check className="w-12 h-12 mx-auto mb-2" />
            <div className="text-xl font-bold">ACCEPT</div>
          </div>
        </div>
      )}

      {showOverlay === 'reject' && (
        <div 
          className="absolute inset-0 bg-red-500 bg-opacity-90 flex items-center justify-center transition-opacity duration-200"
          style={{ opacity: overlayOpacity }}
        >
          <div className="text-center text-white">
            <LucideIcons.X className="w-12 h-12 mx-auto mb-2" />
            <div className="text-xl font-bold">REJECT</div>
          </div>
        </div>
      )}
    </Card>
  );
}
