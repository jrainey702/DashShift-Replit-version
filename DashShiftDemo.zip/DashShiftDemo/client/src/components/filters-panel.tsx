import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent } from "@/components/ui/card";
import * as LucideIcons from "lucide-react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";
import { appIcons } from "@/data/mock-jobs";

interface FiltersPanelProps {
  isOpen: boolean;
  onClose: () => void;
  filters: {
    minPay: number;
    maxDistance: number;
    enabledApps: string[];
  };
  onFiltersChange: (filters: {
    minPay: number;
    maxDistance: number;
    enabledApps: string[];
  }) => void;
}

const availableApps = [
  { name: 'DoorDash', color: 'bg-red-500', icon: 'utensils' },
  { name: 'Uber', color: 'bg-black', icon: 'car' },
  { name: 'Instacart', color: 'bg-green-500', icon: 'shopping-cart' },
  { name: 'Grubhub', color: 'bg-blue-500', icon: 'shopping-bag' },
  { name: 'Amazon Flex', color: 'bg-purple-500', icon: 'package' },
  { name: 'Lyft', color: 'bg-pink-500', icon: 'car' },
  { name: 'Postmates', color: 'bg-yellow-500', icon: 'coffee' },
  { name: 'Shipt', color: 'bg-emerald-500', icon: 'shopping-cart' }
];

export function FiltersPanel({ isOpen, onClose, filters, onFiltersChange }: FiltersPanelProps) {
  const [localFilters, setLocalFilters] = useState(filters);

  useEffect(() => {
    setLocalFilters(filters);
  }, [filters]);

  const handleMinPayChange = (value: number[]) => {
    setLocalFilters(prev => ({ ...prev, minPay: value[0] }));
  };

  const handleMaxDistanceChange = (value: number[]) => {
    setLocalFilters(prev => ({ ...prev, maxDistance: value[0] }));
  };

  const handleAppToggle = (appName: string, checked: boolean) => {
    setLocalFilters(prev => ({
      ...prev,
      enabledApps: checked 
        ? [...prev.enabledApps, appName]
        : prev.enabledApps.filter(app => app !== appName)
    }));
  };

  const handleApplyFilters = () => {
    onFiltersChange(localFilters);
    onClose();
  };

  const handleResetFilters = () => {
    const defaultFilters = {
      minPay: 5,
      maxDistance: 10,
      enabledApps: availableApps.map(app => app.name)
    };
    setLocalFilters(defaultFilters);
  };

  return (
    <div 
      className={cn(
        "fixed inset-0 bg-white z-50 transform transition-transform duration-300",
        isOpen ? "translate-y-0" : "translate-y-full"
      )}
    >
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="bg-white border-b-2 border-blue-300 px-4 py-3 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Filters</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>
        
        {/* Content */}
        <ScrollArea className="flex-1">
          <div className="p-4 space-y-6">
            
            {/* Minimum Pay Filter */}
            <Card>
              <CardContent className="p-4">
                <Label className="text-sm font-medium text-gray-700 mb-4 block">
                  Minimum Pay
                </Label>
                <div className="space-y-4">
                  <Slider
                    value={[localFilters.minPay]}
                    onValueChange={handleMinPayChange}
                    min={5}
                    max={50}
                    step={0.25}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-gray-500">
                    <span>$5</span>
                    <span className="font-medium text-blue-600">${localFilters.minPay.toFixed(2)}</span>
                    <span>$50+</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Maximum Distance Filter */}
            <Card>
              <CardContent className="p-4">
                <Label className="text-sm font-medium text-gray-700 mb-4 block">
                  Maximum Distance
                </Label>
                <div className="space-y-4">
                  <Slider
                    value={[localFilters.maxDistance]}
                    onValueChange={handleMaxDistanceChange}
                    min={1}
                    max={20}
                    step={0.1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-gray-500">
                    <span>1 mi</span>
                    <span className="font-medium text-blue-600">{localFilters.maxDistance.toFixed(1)} mi</span>
                    <span>20+ mi</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* App Selection */}
            <Card>
              <CardContent className="p-4">
                <Label className="text-sm font-medium text-gray-700 mb-4 block">
                  Preferred Apps
                </Label>
                <div className="space-y-3">
                  {availableApps.map((app) => {
                    const IconComponent = LucideIcons[appIcons[app.icon] as keyof typeof LucideIcons] as any;
                    const isChecked = localFilters.enabledApps.includes(app.name);
                    
                    return (
                      <div key={app.name} className="flex items-center space-x-3">
                        <Checkbox
                          id={app.name}
                          checked={isChecked}
                          onCheckedChange={(checked) => handleAppToggle(app.name, checked as boolean)}
                        />
                        <Label
                          htmlFor={app.name}
                          className="flex items-center space-x-2 cursor-pointer flex-1"
                        >
                          <div className={cn("w-6 h-6 rounded flex items-center justify-center", app.color)}>
                            {IconComponent && <IconComponent className="w-3 h-3 text-white" />}
                          </div>
                          <span className="text-sm font-medium">{app.name}</span>
                        </Label>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button 
                onClick={handleApplyFilters} 
                className="w-full bg-blue-500 hover:bg-blue-600"
                size="lg"
              >
                Apply Filters
              </Button>
              <Button 
                onClick={handleResetFilters} 
                variant="outline" 
                className="w-full"
                size="lg"
              >
                Reset to Default
              </Button>
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
