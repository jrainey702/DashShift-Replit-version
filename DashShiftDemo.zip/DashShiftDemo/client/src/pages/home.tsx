import { useState, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MultiJobView } from "@/components/multi-job-view";
import { HistoryPanel } from "@/components/history-panel";
import { FiltersPanel } from "@/components/filters-panel";
import { SettingsPanel } from "@/components/settings-panel";
import { Zap, Filter, Settings } from "lucide-react";
import { Job } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface JobWithTimestamp extends Omit<Job, 'id' | 'createdAt'> {
  timestamp: Date;
}

interface AppFilters {
  minPay: number;
  maxDistance: number;
  enabledApps: string[];
}

export default function Home() {
  const [acceptedJobs, setAcceptedJobs] = useState<JobWithTimestamp[]>([]);
  const [rejectedJobs, setRejectedJobs] = useState<JobWithTimestamp[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [filters, setFilters] = useState<AppFilters>({
    minPay: 5,
    maxDistance: 10,
    enabledApps: ['DoorDash', 'Uber', 'Instacart', 'Grubhub', 'Amazon Flex', 'Lyft', 'Postmates', 'Shipt']
  });

  const { toast } = useToast();

  const handleJobAction = useCallback((action: 'accepted' | 'rejected', job: Omit<Job, 'id' | 'createdAt'>) => {
    const jobWithTimestamp = { ...job, timestamp: new Date() };
    
    if (action === 'accepted') {
      setAcceptedJobs(prev => [...prev, jobWithTimestamp]);
      toast({
        title: "Job Accepted!",
        description: `${job.appName} job for $${job.pay.toFixed(2)} accepted`,
        duration: 2000,
      });
    } else {
      setRejectedJobs(prev => [...prev, jobWithTimestamp]);
      toast({
        title: "Job Rejected",
        description: `${job.appName} job rejected`,
        duration: 2000,
      });
    }
  }, [toast]);

  const handleClearHistory = useCallback(() => {
    setAcceptedJobs([]);
    setRejectedJobs([]);
    toast({
      title: "History Cleared",
      description: "All job history has been cleared",
      duration: 2000,
    });
  }, [toast]);

  const handleResetStats = useCallback(() => {
    setAcceptedJobs([]);
    setRejectedJobs([]);
    toast({
      title: "Statistics Reset",
      description: "All statistics have been reset",
      duration: 2000,
    });
  }, [toast]);

  const totalJobs = acceptedJobs.length + rejectedJobs.length;
  const acceptanceRate = totalJobs > 0 ? Math.round((acceptedJobs.length / totalJobs) * 100) : 0;
  const estimatedEarnings = acceptedJobs.reduce((sum, job) => sum + job.pay, 0);

  return (
    <div className="min-h-screen flex flex-col max-w-6xl mx-auto bg-white shadow-xl relative">
      
      {/* Header */}
      <header className="bg-white border-b-2 border-blue-300 px-4 py-3 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
            <Zap className="w-4 h-4 text-white" />
          </div>
          <h1 className="text-xl font-bold text-gray-900">DashShift</h1>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setShowFilters(true)}
            className="p-2 text-gray-600 hover:text-blue-500"
          >
            <Filter className="w-4 h-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setShowSettings(true)}
            className="p-2 text-gray-600 hover:text-blue-500"
          >
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </header>

      {/* Stats Bar */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-100 rounded-none border-x-0 border-t-0">
        <CardContent className="px-4 py-3">
          <div className="flex justify-between text-sm">
            <div className="text-center">
              <div className="font-semibold text-blue-600">{totalJobs}</div>
              <div className="text-blue-500">Today</div>
            </div>
            <div className="text-center">
              <div className="font-semibold text-emerald-600">{acceptanceRate}%</div>
              <div className="text-emerald-500">Accept Rate</div>
            </div>
            <div className="text-center">
              <div className="font-semibold text-purple-600">${estimatedEarnings.toFixed(0)}</div>
              <div className="text-purple-500">Est. Earnings</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content */}
      <MultiJobView
        onJobAction={handleJobAction}
        onToggleHistory={() => setShowHistory(true)}
        filters={filters}
      />

      {/* Panels */}
      <HistoryPanel
        isOpen={showHistory}
        onClose={() => setShowHistory(false)}
        acceptedJobs={acceptedJobs}
        rejectedJobs={rejectedJobs}
      />

      <FiltersPanel
        isOpen={showFilters}
        onClose={() => setShowFilters(false)}
        filters={filters}
        onFiltersChange={setFilters}
      />

      <SettingsPanel
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        onClearHistory={handleClearHistory}
        onResetStats={handleResetStats}
      />
    </div>
  );
}
