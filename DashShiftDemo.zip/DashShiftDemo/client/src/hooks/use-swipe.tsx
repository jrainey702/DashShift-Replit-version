import { useState, useCallback } from 'react';

interface SwipeState {
  isDragging: boolean;
  startX: number;
  currentX: number;
  deltaX: number;
  rotation: number;
}

interface UseSwipeOptions {
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  threshold?: number;
}

export function useSwipe({ onSwipeLeft, onSwipeRight, threshold = 100 }: UseSwipeOptions) {
  const [swipeState, setSwipeState] = useState<SwipeState>({
    isDragging: false,
    startX: 0,
    currentX: 0,
    deltaX: 0,
    rotation: 0,
  });

  const startSwipe = useCallback((clientX: number) => {
    setSwipeState(prev => ({
      ...prev,
      isDragging: true,
      startX: clientX,
      currentX: clientX,
      deltaX: 0,
      rotation: 0,
    }));
  }, []);

  const updateSwipe = useCallback((clientX: number) => {
    setSwipeState(prev => {
      if (!prev.isDragging) return prev;
      
      const deltaX = clientX - prev.startX;
      const rotation = deltaX * 0.1;
      
      return {
        ...prev,
        currentX: clientX,
        deltaX,
        rotation,
      };
    });
  }, []);

  const endSwipe = useCallback(() => {
    const { deltaX } = swipeState;
    
    if (deltaX > threshold && onSwipeRight) {
      onSwipeRight();
    } else if (deltaX < -threshold && onSwipeLeft) {
      onSwipeLeft();
    }
    
    setSwipeState(prev => ({
      ...prev,
      isDragging: false,
      deltaX: 0,
      rotation: 0,
    }));
  }, [swipeState.deltaX, threshold, onSwipeLeft, onSwipeRight]);

  const resetSwipe = useCallback(() => {
    setSwipeState({
      isDragging: false,
      startX: 0,
      currentX: 0,
      deltaX: 0,
      rotation: 0,
    });
  }, []);

  return {
    swipeState,
    startSwipe,
    updateSwipe,
    endSwipe,
    resetSwipe,
  };
}
